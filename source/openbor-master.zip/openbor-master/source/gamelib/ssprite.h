#ifndef SSPRITE_H
#define SSPRITE_H


#define		TRANSPARENT_IDX		0x00


// Scale in 256ths
void putsprite_scaled(int x, int y, s_sprite * frame, s_screen * screen, int scale);


#endif
